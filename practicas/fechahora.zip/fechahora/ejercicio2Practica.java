package fechahora;

import java.util.Scanner;



public class ejercicio2Practica {

public static void main(String[] args) {


  

 System.out.println("Ingrese el nombre del atacante: ");

 Scanner sc = new Scanner(System.in);
    String  atacante = sc.nextLine();

 System.out.println("Ingrese el nombre del defensor: ");

 Scanner sc2 = new Scanner(System.in);

 String defensor = sc.nextLine();

 System.out.println(atacante+"  "+ defensor);

double porcentaje = Math.random()*(0+2)+(0+3);


System.out.println(porcentaje);




}



    
}
